﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruebaCRUDXamarin_UI.ViewModels
{
    public class ActualizarVM
    {
        #region Atributos Privados

        #endregion

        #region Propiedades Públicas

        #endregion

        #region Contructor

        #endregion

        #region Métodos

        #endregion
    }
}
