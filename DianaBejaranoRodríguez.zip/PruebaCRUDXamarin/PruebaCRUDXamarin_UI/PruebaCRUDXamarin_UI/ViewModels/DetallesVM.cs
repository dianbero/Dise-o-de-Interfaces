﻿using PruebaCRUDXamarin_Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace PruebaCRUDXamarin_UI.ViewModels
{
    public class DetallesVM
    {
        #region Atributos Privados
        private clsPersona personaSeleccionada;
        #endregion

        #region Propiedades Públicas

        #endregion

        #region Contructor

        #endregion

        #region Métodos

        #endregion
    }
}
